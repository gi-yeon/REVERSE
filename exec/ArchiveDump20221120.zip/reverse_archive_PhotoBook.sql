-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: reverse_archive
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `PhotoBook`
--

DROP TABLE IF EXISTS `PhotoBook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PhotoBook` (
  `photobook_id` varchar(255) NOT NULL,
  `createdTime` datetime(6) DEFAULT NULL,
  `isDeleted` bit(1) DEFAULT NULL,
  `location` int DEFAULT NULL,
  `theme` varchar(255) DEFAULT NULL,
  `archive_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`photobook_id`),
  KEY `FKqvhgkhje96xiefjes6iojs61r` (`archive_id`),
  CONSTRAINT `FKqvhgkhje96xiefjes6iojs61r` FOREIGN KEY (`archive_id`) REFERENCES `Archive` (`archive_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PhotoBook`
--

LOCK TABLES `PhotoBook` WRITE;
/*!40000 ALTER TABLE `PhotoBook` DISABLE KEYS */;
INSERT INTO `PhotoBook` VALUES ('03c32864-ab32-4ab0-b51a-ec9d1f588f69','2022-11-20 13:50:08.019935',_binary '\0',2,'PARTY','4c260f10-0b05-4bc3-9ad2-20d5e276cf6f'),('05b0d1f5-c2f5-4a78-824e-03820ae36e30','2022-11-20 13:00:57.510062',_binary '\0',2,'PARTY','fb06b08f-0367-4247-9703-b085ecb65a20'),('070f421e-2add-4357-8b11-f3c3b4c5d89b','2022-11-20 13:03:10.270236',_binary '\0',3,'DAILY','33436ee6-87eb-4a7b-aa56-d0af46a5564b'),('1571626b-2dab-475c-855e-d71dcfe5019c','2022-11-20 12:10:19.130578',_binary '\0',2,'PARTY','8cc76f9f-4eb3-4a66-9c8d-3ddbac92c58e'),('1c29d9e2-30b2-4307-985c-10d2ae78201c','2022-11-20 13:00:27.898494',_binary '\0',1,'TRAVEL','84a7761f-2914-4113-9db9-e4eb828e2c8c'),('2f275e90-8c72-4bbd-ba7a-9515088ed144','2022-11-20 13:02:26.336002',_binary '\0',1,'TRAVEL','1b1b297f-c5f9-43d0-8e59-e85de5fe92f0'),('364cfe82-2ded-47a8-b9f3-a0bc8c77b42f','2022-11-20 13:50:08.025395',_binary '\0',3,'DAILY','4c260f10-0b05-4bc3-9ad2-20d5e276cf6f'),('37d9ebf1-2cfe-4110-8643-cc52f87ee0e3','2022-11-20 13:00:57.515296',_binary '\0',3,'DAILY','fb06b08f-0367-4247-9703-b085ecb65a20'),('37de3a14-412e-4e02-acd1-7041e230b2c5','2022-11-20 11:49:45.574040',_binary '\0',1,'TRAVEL','2acc8841-d07f-4b8e-81b9-492b66e8ac56'),('39cfaf05-6c33-43f5-b7c1-0a92b0f715c8','2022-11-20 10:46:50.442944',_binary '\0',2,'PARTY','767cac89-23ec-433e-b30b-5836073212d3'),('3bc6c884-207e-41da-8d21-400648bcea23','2022-11-20 11:33:11.288601',_binary '\0',1,'TRAVEL','6624d68c-20f7-4387-af4b-375509e42b4c'),('449eb06a-7c43-4c0c-b286-13fd5948b98d','2022-11-20 10:49:21.913454',_binary '\0',3,'DAILY','645a008c-9541-4ee2-b6a7-4b6454ca518e'),('44cde0a4-227f-4706-93cf-fc69e692def1','2022-11-20 11:49:45.579659',_binary '\0',2,'PARTY','2acc8841-d07f-4b8e-81b9-492b66e8ac56'),('4526ed75-684b-46bf-9b88-69c3d671a6c6','2022-11-20 13:02:26.343570',_binary '\0',2,'PARTY','1b1b297f-c5f9-43d0-8e59-e85de5fe92f0'),('4d00151f-5405-46d6-beb3-6105fd92d650','2022-11-20 13:03:10.254006',_binary '\0',1,'TRAVEL','33436ee6-87eb-4a7b-aa56-d0af46a5564b'),('4e1a74f0-0245-40ee-86f6-debaf1fadbd6','2022-11-20 13:02:26.349920',_binary '\0',3,'DAILY','1b1b297f-c5f9-43d0-8e59-e85de5fe92f0'),('55238851-8ee9-46e2-bed4-ed1908991aed','2022-11-20 11:33:11.300136',_binary '\0',3,'DAILY','6624d68c-20f7-4387-af4b-375509e42b4c'),('5a2205d7-388a-419a-9f80-97eec79d7008','2022-11-20 11:33:11.293637',_binary '\0',2,'PARTY','6624d68c-20f7-4387-af4b-375509e42b4c'),('65b875a9-e282-4785-a5eb-b9781b491bc5','2022-11-20 12:10:19.136101',_binary '\0',3,'DAILY','8cc76f9f-4eb3-4a66-9c8d-3ddbac92c58e'),('76d5cd86-71e8-45c1-930a-22085b9cf37c','2022-11-20 13:00:27.912893',_binary '\0',2,'PARTY','84a7761f-2914-4113-9db9-e4eb828e2c8c'),('800c2be0-1074-4f53-8cf6-1a36589b8d67','2022-11-20 10:55:28.660027',_binary '\0',2,'PARTY','d4b83581-36a0-4c8c-a941-216fc06f0513'),('81c2fe67-32f2-484f-806e-a8ec6c4febaa','2022-11-20 12:10:19.124650',_binary '\0',1,'TRAVEL','8cc76f9f-4eb3-4a66-9c8d-3ddbac92c58e'),('84c502d1-308d-4985-a95a-b9a53bc1aa42','2022-11-20 13:00:57.503442',_binary '\0',1,'TRAVEL','fb06b08f-0367-4247-9703-b085ecb65a20'),('8c7348f1-1daf-4192-a4a7-0cb7ed885ef8','2022-11-20 10:46:50.416602',_binary '\0',1,'TRAVEL','767cac89-23ec-433e-b30b-5836073212d3'),('aacf9ee4-5127-4a96-a8e3-2107b931d672','2022-11-20 10:55:28.665262',_binary '\0',3,'DAILY','d4b83581-36a0-4c8c-a941-216fc06f0513'),('b28c64cb-f1bd-4f4f-af68-30c405eb1149','2022-11-20 11:49:45.585514',_binary '\0',3,'DAILY','2acc8841-d07f-4b8e-81b9-492b66e8ac56'),('b5022a41-043c-4e8c-b5a0-2524cc9b1948','2022-11-20 10:55:28.653763',_binary '\0',1,'TRAVEL','d4b83581-36a0-4c8c-a941-216fc06f0513'),('b759a8ca-042e-4a32-9c25-a040b827b7b1','2022-11-20 13:50:08.014660',_binary '\0',1,'TRAVEL','4c260f10-0b05-4bc3-9ad2-20d5e276cf6f'),('bed35c60-d63c-497a-bd13-ce44cbf8e101','2022-11-20 12:29:18.017967',_binary '\0',1,'TRAVEL','cbcf4cf6-aa5a-46f4-b4f6-0e8e1136b4f9'),('c7f37b52-1396-4660-a4f7-2d5abb005069','2022-11-20 12:29:18.024287',_binary '\0',2,'PARTY','cbcf4cf6-aa5a-46f4-b4f6-0e8e1136b4f9'),('ddf776ad-8814-42d3-8ad0-a923ad3fec2a','2022-11-20 13:00:27.920791',_binary '\0',3,'DAILY','84a7761f-2914-4113-9db9-e4eb828e2c8c'),('dfbbf0ad-3ca1-451f-9d60-d8825c7eb4ef','2022-11-20 13:03:10.263795',_binary '\0',2,'PARTY','33436ee6-87eb-4a7b-aa56-d0af46a5564b'),('e507c5c8-c609-418b-a7d6-556d49c6eeed','2022-11-20 10:49:21.900895',_binary '\0',1,'TRAVEL','645a008c-9541-4ee2-b6a7-4b6454ca518e'),('eba522bf-a314-4e5f-a741-ed57a0dfedc0','2022-11-20 12:29:18.030460',_binary '\0',3,'DAILY','cbcf4cf6-aa5a-46f4-b4f6-0e8e1136b4f9'),('f72e90c7-f939-4fd5-b65d-88c6e9423d98','2022-11-20 10:49:21.908186',_binary '\0',2,'PARTY','645a008c-9541-4ee2-b6a7-4b6454ca518e'),('f8eeb7e1-7699-4c82-82aa-0bfb9606a30a','2022-11-20 10:46:50.458041',_binary '\0',3,'DAILY','767cac89-23ec-433e-b30b-5836073212d3');
/*!40000 ALTER TABLE `PhotoBook` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 23:21:28
