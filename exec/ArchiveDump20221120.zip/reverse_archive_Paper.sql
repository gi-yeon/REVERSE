-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: reverse_archive
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Paper`
--

DROP TABLE IF EXISTS `Paper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Paper` (
  `paper_id` varchar(255) NOT NULL,
  `content` longtext,
  `createdTime` datetime(6) DEFAULT NULL,
  `isDeleted` bit(1) DEFAULT NULL,
  `lastEditedTime` datetime(6) DEFAULT NULL,
  `memoryTime` date DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `writer` varchar(255) DEFAULT NULL,
  `stuff_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`paper_id`),
  KEY `FKlu9b81q3vrho32orqniex0xas` (`stuff_id`),
  CONSTRAINT `FKlu9b81q3vrho32orqniex0xas` FOREIGN KEY (`stuff_id`) REFERENCES `Stuff` (`stuff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Paper`
--

LOCK TABLES `Paper` WRITE;
/*!40000 ALTER TABLE `Paper` DISABLE KEYS */;
INSERT INTO `Paper` VALUES ('04023d3d-5e71-48e8-965c-5a6324a970f7','<p><span style=\"background-color: rgb(204, 232, 204);\">이 다이어리는 나 바권창 바이러스에 감염됐다!!</span></p><p><br></p><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/53b948da-989d-4f2d-8b2a-4dcd99acdc97_%EB%82%98%EB%B0%94%EA%B6%8C%EC%B0%BD%EB%B0%94%EC%9D%B4%EB%9F%AC%EC%8A%A4.png\" width=\"531\" style=\"\"></p>','2022-11-20 11:37:26.403717',_binary '\0','2022-11-20 11:37:26.403724','2022-11-02','나바권창 바이러스','나바권창','c2796a43-0a51-444a-8022-d9901786fea5'),('17dc86ee-2a65-47dd-ba7f-0a7db44c884e','<p>슈슈슉탕</p><p>슈슈슉탕</p><p>슈슈슉팡</p>','2022-11-20 12:31:05.138650',_binary '\0','2022-11-20 12:31:05.138656','2022-11-20','싼데비슷한','싼데비스탄','34f38791-d0e4-418a-ad1c-a69cbac37d88'),('56056604-d667-4038-b772-31ad787ffd9f','<p>마유선 교육생 감사합니다~!!</p><p><br></p><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/90e906c0-dc3d-4c90-9370-3202bfa76312_%EB%BA%B4%EB%BA%B4%EB%A1%9C.jpg\"></p>','2022-11-20 12:34:29.797320',_binary '\0','2022-11-20 12:34:29.797323','2022-11-11','빼빼로데이! ','지용현','e8d6003d-858c-4ee3-8cf4-fb7e12164bbb'),('69d2ddf0-e0b7-4836-b66d-8f5cfbc75b37','<p>강한사람은 춥지 않지</p><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/04a9ff6d-5864-4f7b-ad9d-31f0defa5edc_%EA%B3%84%EC%A0%88%EA%B7%B8%EB%A6%BC.png\" width=\"432\" style=\"\"></p><h2><span style=\"color: rgb(255, 153, 0);\">나는 추위를 느껴본 적이 없는걸..?</span></h2><p><br></p><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/3d57ca1d-4c1a-4cce-84c7-50af5524a826_%EA%B3%84%EC%A0%88%EC%82%AC%EC%A7%84.jpg\" width=\"578\" style=\"cursor: nwse-resize;\"></p>','2022-11-20 11:42:52.101938',_binary '\0','2022-11-20 11:42:52.101942','2022-11-16','추위가 뭐지?','나바권창','c2796a43-0a51-444a-8022-d9901786fea5'),('6a36b430-f6ce-4b9f-bc4f-dad96eb992b8','<p>이 세계는 곧 내가 지배한다...</p><p><br></p><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/bf0cc547-f70a-4576-a9f5-40ed30788621_%EC%9D%B4%EC%84%B8%EA%B3%84%EB%A5%BC%ED%8F%89%EC%A0%95%ED%95%98%EB%A6%AC%EB%8B%A4%EC%82%AC%EC%A7%84.png\"></p><p><br></p><h2><strong style=\"background-color: rgb(0, 138, 0); color: rgb(255, 255, 0);\">훗....</strong></h2><p><br></p><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/d8c7e7cb-d310-4972-ab67-fa698bb8330d_%EC%9D%B4%EC%84%B8%EA%B3%84%EB%A5%BC%ED%8F%89%EC%A0%95%ED%95%98%EB%A6%AC%EB%8B%A4%EA%B7%B8%EB%A6%BC.png\"></p>','2022-11-20 11:41:00.668059',_binary '\0','2022-11-20 11:41:10.664778','2022-11-09','이세계를 평정하겠어','나바권창','c2796a43-0a51-444a-8022-d9901786fea5'),('8687e196-2484-4d46-96be-7a3bd2f37f36','<h3>강자는 울지 않아... 그저 물이 중력을 받을 뿐...</h3><p><br></p><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/c33c30f7-daef-4937-886f-f7febba0872c_%EB%88%88%EB%AC%BC.png\"></p>','2022-11-20 11:48:06.070121',_binary '\0','2022-11-20 11:48:06.070126','2022-11-11','눈물 그게 뭐야?','나바권창','c2796a43-0a51-444a-8022-d9901786fea5'),('a2a4aef4-e429-411b-9eb1-32d6b587ede0','<p>나에게 빠지는 하루다...</p><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/a3e9141b-62a0-4d65-abfa-f540e16b06b2_%EC%9E%90%EC%95%84%EB%8F%84%EC%B7%A8%EC%82%AC%EC%A7%84.png\" width=\"387\" style=\"\"></p><h3><span style=\"color: rgb(230, 0, 0);\">난 너무 강해...</span></h3><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/f3df1c59-3155-4e7b-ac03-4deff64596ca_%EC%9E%90%EC%95%84%EB%8F%84%EC%B7%A8%EA%B7%B8%EB%A6%BC.png\" width=\"602\" style=\"\"></p>','2022-11-20 11:39:00.625810',_binary '\0','2022-11-20 11:39:00.625815','2022-11-05','나바권창 멋있어....','나바권창','c2796a43-0a51-444a-8022-d9901786fea5'),('a97053c5-9bf2-45dd-9031-f36ada8edfb0','<p>재밌었다!</p><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/8a88a955-f8e9-4a32-9c09-627ab3ffc815_%EB%B0%8B%EC%97%85%EC%82%AC%EC%A7%84.jpg\" style=\"--tw-border-spacing-x:0; --tw-border-spacing-y:0; --tw-translate-x:0; --tw-translate-y:0; --tw-rotate:0; --tw-skew-x:0; --tw-skew-y:0; --tw-scale-x:1; --tw-scale-y:1; --tw-pan-x: ; --tw-pan-y: ; --tw-pinch-zoom: ; --tw-scroll-snap-strictness:proximity; --tw-ordinal: ; --tw-slashed-zero: ; --tw-numeric-figure: ; --tw-numeric-spacing: ; --tw-numeric-fraction: ; --tw-ring-inset: ; --tw-ring-offset-width:0px; --tw-ring-offset-color:#fff; --tw-ring-color:rgba(59,130,246,0.5); --tw-ring-offset-shadow:0 0 #0000; --tw-ring-shadow:0 0 #0000; --tw-shadow:0 0 #0000; --tw-shadow-colored:0 0 #0000; --tw-blur: ; --tw-brightness: ; --tw-contrast: ; --tw-grayscale: ; --tw-hue-rotate: ; --tw-invert: ; --tw-saturate: ; --tw-sepia: ; --tw-drop-shadow: ; --tw-backdrop-blur: ; --tw-backdrop-brightness: ; --tw-backdrop-contrast: ; --tw-backdrop-grayscale: ; --tw-backdrop-hue-rotate: ; --tw-backdrop-invert: ; --tw-backdrop-opacity: ; --tw-backdrop-saturate: ; --tw-backdrop-sepia: ; border-color: var(--chakra-colors-chakra-border-color); cursor: nwse-resize;\" width=\"506\"></p><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/1febcc8a-5041-4858-9648-c56efe5e09cd_%EB%A1%A4%EC%BC%80%EC%9E%8C.jpg\" width=\"228\" style=\"\"></p><p><br></p>','2022-11-20 12:33:46.367712',_binary '\0','2022-11-20 12:33:46.367718','2022-10-26','싸피 밋업!','지용현','e8d6003d-858c-4ee3-8cf4-fb7e12164bbb'),('be0ac25b-b453-4b24-a367-308e0fe9c922','<p>살기위해...</p><p><br></p><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/075b520c-e62e-4467-b217-b7af9556e26b_%EC%BB%A4%ED%94%BC2.jpg\"></p>','2022-11-20 12:34:50.858544',_binary '\0','2022-11-20 12:34:50.858548','2022-11-03','오늘도 커피를...','지용현','e8d6003d-858c-4ee3-8cf4-fb7e12164bbb'),('c184ec6e-f9a0-41a2-8f6f-bcb7ff822ca3','<p>카페인이 필요해...</p><p><br></p><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/597d11a4-fbd3-425b-b2d4-0c76c9b09dcf_%EC%BB%A4%ED%94%BC3.jpg\"></p>','2022-11-20 12:35:27.587050',_binary '\0','2022-11-20 12:35:27.587055','2022-10-28','커피 충전!','지용현','e8d6003d-858c-4ee3-8cf4-fb7e12164bbb'),('f3a6e38b-f262-470b-8d29-31936379e60b','<h2><strong>와ㅏㅏㅏ!!!</strong></h2><p><br></p><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/a6e7f26d-8ebb-44f2-a07c-8346d9d7947d_%EC%8A%A4%EB%B2%85.jpg\"></p>','2022-11-20 12:30:43.957300',_binary '\0','2022-11-20 12:30:43.957306','2022-11-04','오늘은 윤영이가 쏘는 스벅!','지용현','e8d6003d-858c-4ee3-8cf4-fb7e12164bbb'),('f6637e8a-d354-4617-9a2c-39403b4e200e','<p>카페인 충전....</p><p><br></p><p><img src=\"https://re-verse-bucket.s3.ap-northeast-2.amazonaws.com/image/feba9566-8c74-4f33-a72e-55f746fe5d04_%EC%BB%A4%ED%94%BC.jpg\"></p>','2022-11-20 12:30:15.246318',_binary '\0','2022-11-20 12:30:15.246322','2022-11-02','커피가 필요해','지용현','e8d6003d-858c-4ee3-8cf4-fb7e12164bbb');
/*!40000 ALTER TABLE `Paper` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 23:21:49
