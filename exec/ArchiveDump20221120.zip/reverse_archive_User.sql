-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: reverse_archive
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `user_id` varchar(255) NOT NULL,
  `auth_id` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `bestArchiveId` varchar(255) DEFAULT NULL,
  `createdTime` date DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES ('3f2e9d5e-1ae8-4625-aa91-7210e0770a32','31d8adad-96f9-415b-b2ad-5f8dd342c8c7','Cat','84a7761f-2914-4113-9db9-e4eb828e2c8c','2022-11-20','리버스로 놀러오세요 :)','KIN거운KAN쵸'),('6b463135-b391-45b6-ba95-1ec9dbe21811','04730caa-498a-4bc0-927c-424e190a6299','Husky','cbcf4cf6-aa5a-46f4-b4f6-0e8e1136b4f9','2022-11-20','리버스로 놀러오세요 :)','싼데비스탄'),('94bdb053-591c-45c2-8cd5-862b162ed695','2551cefe-911f-4f15-81a5-c2f6d665d01e','Cat','33436ee6-87eb-4a7b-aa56-d0af46a5564b','2022-11-20','리버스로 놀러오세요 :)','갓영진'),('adde7fb4-1c0a-4f0f-80b3-a103bd2def40','8373d9c8-0937-4ab0-8270-f83c743daea2','Cat','fb06b08f-0367-4247-9703-b085ecb65a20','2022-11-20','리버스로 놀러오세요 :)','갓찬국'),('b45724f0-ee3e-4599-8264-d344c124d65d','4255df2b-acc0-4682-8ca3-dc5177dfc4d6','Beluga','6624d68c-20f7-4387-af4b-375509e42b4c','2022-11-20','리버스로 놀러오세요 :)','나바권창'),('b4dd4730-9814-4418-8282-209a2f782c3a','ce1b0846-273e-4a56-9fac-e0d8838666fb','Cat','1b1b297f-c5f9-43d0-8e59-e85de5fe92f0','2022-11-20','리버스로 놀러오세요 :)','갓하은'),('e1f62b82-56a8-4adf-aca3-31d0bce2a17b','16cb4589-0128-474b-a450-8074ed4fc357','Tortoise','8cc76f9f-4eb3-4a66-9c8d-3ddbac92c58e','2022-11-20','리버스로 놀러오세요 :)','지용현'),('ea506064-00d8-43fa-aabc-2bda83d75480','5d5bcc1b-295b-43b8-a4cc-b99f07570972','Cat','2acc8841-d07f-4b8e-81b9-492b66e8ac56','2022-11-20','리버스로 놀러오세요 :)','정기연'),('f4eb08be-b498-41dc-a432-9f62d72fe69c','d0f52b85-9a6b-4166-9e87-02119283f38a','Cat','4c260f10-0b05-4bc3-9ad2-20d5e276cf6f','2022-11-20','리버스로 놀러오세요 :)','바바');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 23:21:37
