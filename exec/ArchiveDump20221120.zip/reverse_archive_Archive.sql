-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: reverse_archive
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Archive`
--

DROP TABLE IF EXISTS `Archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Archive` (
  `archive_id` varchar(255) NOT NULL,
  `createdTime` datetime(6) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `isDeleted` bit(1) DEFAULT NULL,
  `owner_id` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`archive_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Archive`
--

LOCK TABLES `Archive` WRITE;
/*!40000 ALTER TABLE `Archive` DISABLE KEYS */;
INSERT INTO `Archive` VALUES ('1b1b297f-c5f9-43d0-8e59-e85de5fe92f0','2022-11-20 13:02:26.308500','친구와 나의 추억을 공유해보세요 :)',_binary '\0','b4dd4730-9814-4418-8282-209a2f782c3a','나의 첫 아카이브'),('2acc8841-d07f-4b8e-81b9-492b66e8ac56','2022-11-20 11:49:45.552654','친구와 나의 추억을 공유해보세요 :)',_binary '\0','ea506064-00d8-43fa-aabc-2bda83d75480','나의 첫 아카이브'),('33436ee6-87eb-4a7b-aa56-d0af46a5564b','2022-11-20 13:03:10.234402','친구와 나의 추억을 공유해보세요 :)',_binary '\0','94bdb053-591c-45c2-8cd5-862b162ed695','나의 첫 아카이브'),('4c260f10-0b05-4bc3-9ad2-20d5e276cf6f','2022-11-20 13:50:07.993759','친구와 나의 추억을 공유해보세요 :)',_binary '\0','f4eb08be-b498-41dc-a432-9f62d72fe69c','나의 첫 아카이브'),('645a008c-9541-4ee2-b6a7-4b6454ca518e','2022-11-20 10:49:21.885603','슈슈슉팡',_binary '\0','b45724f0-ee3e-4599-8264-d344c124d65d','산데비스탄'),('6624d68c-20f7-4387-af4b-375509e42b4c','2022-11-20 11:33:11.276333','나바권창 시리즈 모음집',_binary '\0','b45724f0-ee3e-4599-8264-d344c124d65d','나바권창'),('767cac89-23ec-433e-b30b-5836073212d3','2022-11-20 10:46:50.320088','친구와 나의 추억을 공유해보세요 :)',_binary '\0','b45724f0-ee3e-4599-8264-d344c124d65d','나의 첫 아카이브'),('84a7761f-2914-4113-9db9-e4eb828e2c8c','2022-11-20 13:00:27.869163','친구와 나의 추억을 공유해보세요 :)',_binary '\0','3f2e9d5e-1ae8-4625-aa91-7210e0770a32','나의 첫 아카이브'),('8cc76f9f-4eb3-4a66-9c8d-3ddbac92c58e','2022-11-20 12:10:19.111610','리버스 멤버들과 추억',_binary '\0','e1f62b82-56a8-4adf-aca3-31d0bce2a17b','리버스'),('cbcf4cf6-aa5a-46f4-b4f6-0e8e1136b4f9','2022-11-20 12:29:17.989805','친구와 나의 추억을 공유해보세요 :)',_binary '\0','6b463135-b391-45b6-ba95-1ec9dbe21811','나의 첫 아카이브'),('d4b83581-36a0-4c8c-a941-216fc06f0513','2022-11-20 10:55:28.633043','친구와 나의 추억을 공유해보세요 :)',_binary '\0','e1f62b82-56a8-4adf-aca3-31d0bce2a17b','나의 첫 아카이브'),('fb06b08f-0367-4247-9703-b085ecb65a20','2022-11-20 13:00:57.485568','친구와 나의 추억을 공유해보세요 :)',_binary '\0','adde7fb4-1c0a-4f0f-80b3-a103bd2def40','나의 첫 아카이브');
/*!40000 ALTER TABLE `Archive` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 23:21:47
