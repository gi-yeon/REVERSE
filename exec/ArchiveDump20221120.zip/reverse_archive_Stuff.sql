-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: reverse_archive
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Stuff`
--

DROP TABLE IF EXISTS `Stuff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Stuff` (
  `stuff_id` varchar(255) NOT NULL,
  `createdTime` datetime(6) DEFAULT NULL,
  `isDeleted` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `archive_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`stuff_id`),
  KEY `FK1ff8a58cvm7rdnm0i4wlh3dge` (`archive_id`),
  CONSTRAINT `FK1ff8a58cvm7rdnm0i4wlh3dge` FOREIGN KEY (`archive_id`) REFERENCES `Archive` (`archive_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Stuff`
--

LOCK TABLES `Stuff` WRITE;
/*!40000 ALTER TABLE `Stuff` DISABLE KEYS */;
INSERT INTO `Stuff` VALUES ('04650a0e-557a-4e87-a290-9b2918d7a92d','2022-11-20 11:49:45.598490',_binary '\0','stuff',NULL,'WRITE_ONLY','2acc8841-d07f-4b8e-81b9-492b66e8ac56'),('05ed227d-8d9b-463d-97c0-022075746caf','2022-11-20 13:03:10.299622',_binary '\0','stuff',NULL,'WRITE_ONLY','33436ee6-87eb-4a7b-aa56-d0af46a5564b'),('0ca9d3ba-5572-496c-86ab-9d31d40213e7','2022-11-20 12:29:18.036850',_binary '\0','stuff',NULL,'WRITE_ONLY','cbcf4cf6-aa5a-46f4-b4f6-0e8e1136b4f9'),('12d51124-b6cf-4ef9-86d3-0599da22d752','2022-11-20 13:50:08.031543',_binary '\0','stuff',NULL,'WRITE_ONLY','4c260f10-0b05-4bc3-9ad2-20d5e276cf6f'),('12dc3099-5f42-4636-8873-05fb2efe1b98','2022-11-20 13:00:57.526559',_binary '\0','stuff',NULL,'WRITE_ONLY','fb06b08f-0367-4247-9703-b085ecb65a20'),('17f1f9bd-a3ac-4909-afc3-b73fec67d512','2022-11-20 13:50:08.037126',_binary '\0','stuff',NULL,'WRITE_ONLY','4c260f10-0b05-4bc3-9ad2-20d5e276cf6f'),('1e21dfc5-7924-4425-8ed4-5f35889f1724','2022-11-20 13:00:57.533844',_binary '\0','stuff',NULL,'WRITE_ONLY','fb06b08f-0367-4247-9703-b085ecb65a20'),('2ab59ba6-ae67-4ac0-be68-f418a462b5c2','2022-11-20 11:49:45.591289',_binary '\0','stuff',NULL,'WRITE_ONLY','2acc8841-d07f-4b8e-81b9-492b66e8ac56'),('34f38791-d0e4-418a-ad1c-a69cbac37d88','2022-11-20 12:29:18.046753',_binary '\0','stuff',NULL,'WRITE_ONLY','cbcf4cf6-aa5a-46f4-b4f6-0e8e1136b4f9'),('353677d1-febc-44a4-8adf-14c7faa888d7','2022-11-20 10:55:28.683445',_binary '\0','stuff',NULL,'WRITE_ONLY','d4b83581-36a0-4c8c-a941-216fc06f0513'),('3b295c79-e2bd-4954-9163-859144710891','2022-11-20 12:29:18.042388',_binary '\0','stuff',NULL,'WRITE_ONLY','cbcf4cf6-aa5a-46f4-b4f6-0e8e1136b4f9'),('3d27007d-904e-4673-b30a-a5309c62a28f','2022-11-20 13:00:57.520736',_binary '\0','stuff',NULL,'WRITE_ONLY','fb06b08f-0367-4247-9703-b085ecb65a20'),('3d313495-fa9a-45ad-a29a-eaeb89ff6a8e','2022-11-20 13:03:10.278294',_binary '\0','stuff',NULL,'WRITE_ONLY','33436ee6-87eb-4a7b-aa56-d0af46a5564b'),('40bb4c14-8f74-4d4e-8997-12d5552fa2dc','2022-11-20 11:33:11.326219',_binary '\0','stuff',NULL,'WRITE_ONLY','6624d68c-20f7-4387-af4b-375509e42b4c'),('5fa41968-9c87-4b4a-b941-97e2a6865c3a','2022-11-20 10:46:50.473120',_binary '\0','stuff',NULL,'WRITE_ONLY','767cac89-23ec-433e-b30b-5836073212d3'),('60e54716-726c-4b88-b3d9-f6227b1b3978','2022-11-20 13:50:08.042272',_binary '\0','stuff',NULL,'WRITE_ONLY','4c260f10-0b05-4bc3-9ad2-20d5e276cf6f'),('64e5a418-cc12-48c9-a33d-07136fdc20e8','2022-11-20 10:55:28.676905',_binary '\0','stuff',NULL,'WRITE_ONLY','d4b83581-36a0-4c8c-a941-216fc06f0513'),('8a3a2d88-5a20-438e-9c65-9acd04c3671d','2022-11-20 13:00:27.930438',_binary '\0','stuff',NULL,'WRITE_ONLY','84a7761f-2914-4113-9db9-e4eb828e2c8c'),('ac491cf3-8c93-4eac-82be-eea971b39034','2022-11-20 11:33:11.305605',_binary '\0','stuff',NULL,'WRITE_ONLY','6624d68c-20f7-4387-af4b-375509e42b4c'),('aea58478-71fc-4c59-8e72-2c4f81a9f422','2022-11-20 10:49:21.921794',_binary '\0','stuff',NULL,'WRITE_ONLY','645a008c-9541-4ee2-b6a7-4b6454ca518e'),('b6e894f4-7e63-4f1c-b349-ac047c573aa3','2022-11-20 12:10:19.151624',_binary '\0','stuff',NULL,'WRITE_ONLY','8cc76f9f-4eb3-4a66-9c8d-3ddbac92c58e'),('bf65dd77-b92d-4e54-88f3-2daefed5748f','2022-11-20 13:00:27.943996',_binary '\0','stuff',NULL,'WRITE_ONLY','84a7761f-2914-4113-9db9-e4eb828e2c8c'),('c2796a43-0a51-444a-8022-d9901786fea5','2022-11-20 11:33:11.314437',_binary '\0','stuff',NULL,'WRITE_ONLY','6624d68c-20f7-4387-af4b-375509e42b4c'),('c50d9c0a-2313-4bde-96cd-da3447f6dae9','2022-11-20 13:03:10.286236',_binary '\0','stuff',NULL,'WRITE_ONLY','33436ee6-87eb-4a7b-aa56-d0af46a5564b'),('c5d9b89c-e2be-4be4-9900-c61dd67defd3','2022-11-20 10:46:50.508208',_binary '\0','stuff',NULL,'WRITE_ONLY','767cac89-23ec-433e-b30b-5836073212d3'),('c847e797-86a4-44df-8b86-43e05df8ef2a','2022-11-20 13:02:26.367725',_binary '\0','stuff',NULL,'WRITE_ONLY','1b1b297f-c5f9-43d0-8e59-e85de5fe92f0'),('d64766ac-e24c-4254-9023-d604fc744763','2022-11-20 13:00:27.938244',_binary '\0','stuff',NULL,'WRITE_ONLY','84a7761f-2914-4113-9db9-e4eb828e2c8c'),('e1186aae-811e-4ad2-afee-2ffb20984133','2022-11-20 10:46:50.493228',_binary '\0','stuff',NULL,'WRITE_ONLY','767cac89-23ec-433e-b30b-5836073212d3'),('e16b20f5-7f81-42bb-8561-f49efc3f7699','2022-11-20 12:10:19.146557',_binary '\0','stuff',NULL,'WRITE_ONLY','8cc76f9f-4eb3-4a66-9c8d-3ddbac92c58e'),('e75d3774-7611-46ea-989d-44fb58e45ccc','2022-11-20 13:02:26.360630',_binary '\0','stuff',NULL,'WRITE_ONLY','1b1b297f-c5f9-43d0-8e59-e85de5fe92f0'),('e8d6003d-858c-4ee3-8cf4-fb7e12164bbb','2022-11-20 12:10:19.142044',_binary '\0','stuff',NULL,'WRITE_ONLY','8cc76f9f-4eb3-4a66-9c8d-3ddbac92c58e'),('ee60e744-c59b-43b9-b791-90ed49bd8120','2022-11-20 10:55:28.670821',_binary '\0','stuff',NULL,'WRITE_ONLY','d4b83581-36a0-4c8c-a941-216fc06f0513'),('f187d69a-d12c-421c-9cb2-4956d70f4834','2022-11-20 13:02:26.355170',_binary '\0','stuff',NULL,'WRITE_ONLY','1b1b297f-c5f9-43d0-8e59-e85de5fe92f0'),('f6c0dab6-1034-48e1-9ba4-ad619473d399','2022-11-20 10:49:21.929445',_binary '\0','stuff',NULL,'WRITE_ONLY','645a008c-9541-4ee2-b6a7-4b6454ca518e'),('f75bce07-974b-4bb1-a5d2-2f1431df6706','2022-11-20 11:49:45.605059',_binary '\0','stuff',NULL,'WRITE_ONLY','2acc8841-d07f-4b8e-81b9-492b66e8ac56'),('fd3f8e22-be8c-40a5-8544-4a182bdb5f0a','2022-11-20 10:49:21.935806',_binary '\0','stuff',NULL,'WRITE_ONLY','645a008c-9541-4ee2-b6a7-4b6454ca518e');
/*!40000 ALTER TABLE `Stuff` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 23:21:32
