-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: reverse_auth
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Auth`
--

DROP TABLE IF EXISTS `Auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Auth` (
  `auth_id` varchar(255) NOT NULL,
  `authority` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_status_id` bigint DEFAULT NULL,
  PRIMARY KEY (`auth_id`),
  KEY `FK4by6l9lfpu17qhatv8a477n97` (`user_status_id`),
  CONSTRAINT `FK4by6l9lfpu17qhatv8a477n97` FOREIGN KEY (`user_status_id`) REFERENCES `user_status` (`user_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Auth`
--

LOCK TABLES `Auth` WRITE;
/*!40000 ALTER TABLE `Auth` DISABLE KEYS */;
INSERT INTO `Auth` VALUES ('04730caa-498a-4bc0-927c-424e190a6299','ROLE_USER','parkwc0213@gmail.com','$2a$10$CO.DwZjoSskaMADg6zgqj.O804H0fJCK.KwrMC4ABSvHaBorpKmby',4),('16cb4589-0128-474b-a450-8074ed4fc357','ROLE_USER','yung5487@naver.com','$2a$10$BjaGf361fcDP1FZ9DlSTEOnah4L4yXFbDL7rRePBUp8AfKrAQZV9S',2),('2551cefe-911f-4f15-81a5-c2f6d665d01e','ROLE_USER','god@young.jin','$2a$10$Umem3UvnRX4oWc4G4lWJbuYK/rrYtLlunGYoiDRJsm3XF.d7ekBTO',8),('31d8adad-96f9-415b-b2ad-5f8dd342c8c7','ROLE_USER','noni@naver.com','$2a$10$CKj5WOuc/lhxy780IOqj6u3z6c.WSlbwF1jkjXjHTg4LDInZM2Q2C',5),('4255df2b-acc0-4682-8ca3-dc5177dfc4d6','ROLE_USER','parkwc0213@naver.com','$2a$10$GxtzatPrs4cvE1wAJBDxgOr7HwsexDg2ICv7mB8Rz10g9YHMaQEtW',1),('5d5bcc1b-295b-43b8-a4cc-b99f07570972','ROLE_USER','ssafy@naver.com','$2a$10$wmFFyj3.RZ70mZZk.3a4wuFDY.NwbyBMoUEPPzWDddQUjYVV44erG',3),('8373d9c8-0937-4ab0-8270-f83c743daea2','ROLE_USER','god@chan.kuk','$2a$10$3TDcODNueKwlAvzBlKuxI.1VLd/RyW.n0tQ1COiuaur5f6dKkRhmG',6),('ce1b0846-273e-4a56-9fac-e0d8838666fb','ROLE_USER','god@ha.eun','$2a$10$SHWhaPdYFyUJMtZgzB.PBu/FJShiaapXleaybEWLgAtCbTTv5BV8y',7),('d0f52b85-9a6b-4166-9e87-02119283f38a','ROLE_USER','a@a.com','$2a$10$IXBu/IvmtPBDOI0SMKNZF.9zEC5h36XPJyEsA3IZPk40tuGyawiLi',9);
/*!40000 ALTER TABLE `Auth` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 23:19:23
